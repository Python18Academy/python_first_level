from simple_class import Car

jugl = Car("jigul", 110)
audi = Car("audi", 150)
nissan = Car("nissan", 90)
print(jugl.car_ride())
print(audi.car_ride())
print(nissan.car_ride())