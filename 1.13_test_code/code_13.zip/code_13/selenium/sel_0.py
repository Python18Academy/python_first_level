from selenium import webdriver

browser = webdriver.Chrome()
browser.get('http://selenium.dev/')